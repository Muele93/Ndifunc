#mypackage
This library was created to show Python recursion funtions

# Building the package locally
'python setup.py sdist'

#Installation from Github
'pip install git+https://github.com/Ndivhuwo-Tshilande/example-python-function.git'

# Updating package on Github
'pip install --upgrade git+https://github.com/Nivhuwo-Tshilande/example-python-function.git'
